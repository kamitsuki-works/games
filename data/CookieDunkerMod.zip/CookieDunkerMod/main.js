Game.registerMod("cookie-dunker mod",{
	init:function(){
		Game.resize=function()
		{
			var w=window.innerWidth;
			var h=window.innerHeight;
			
			var prevW=Game.windowW;
			
			var scale=Math.min(
				w/Math.max(600,w), // original:800
				h/Math.max(360,h), // original:480, however must be less than 448 to win 'Cookie-dunker'
			);
			Game.windowW=Math.floor(w/scale);
			Game.windowH=Math.floor(h/scale);
			if (scale!=1)
			{
				Game.wrapper.style.transform='scale('+(scale)+')';
				Game.wrapper.style.width=Game.windowW+'px';
				Game.wrapper.style.height=Game.windowH+'px';
			}
			else
			{
				Game.wrapper.style.removeProperty('transform');
				Game.wrapper.style.width='100%';
				Game.wrapper.style.height='100%';
			}
			Game.scale=scale;
			
			for (var i in Game.Objects)
			{
				var me=Game.Objects[i];
				me.toResize=true;
				if (me.minigame && me.minigame.onResize) me.minigame.onResize();
			}
			
			if (Game.getNewTicker)
			{
				if (prevW>=1000 && Game.windowW<1000) Game.getNewTicker(true);
				else if (prevW<1000 && Game.windowW>=1000) Game.getNewTicker(true);
			}
		}
		Game.Notify(`Example mod loaded!`,'',[16,5]);
	},
	save:function(){
	},
	load:function(str){
	},
});
